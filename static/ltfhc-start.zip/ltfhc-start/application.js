window.onload = function() {
  document.querySelector('#reset').onclick = function() {
    window.close();
  };
}